<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HyperGYM</title>
    <link rel="stylesheet" href="contact.css">
</head>
<body>

    <nav>
        <div class="menu">
          <div class="logo">+
            <a href="#">HYPERGYM</a>
          </div>
          <ul>
            <li><a href="HYPERGYM.php">Home</a></li>
            <li><a href="About.php">About</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="contact.php">Contact</a></li>
        
          </ul>
        </div>
      </nav>
      <div class="container">
        <form action="action_page.php">
      
          <label for="fname">First Name</label>
          <input type="text" id="fname" name="firstname" placeholder="Your name..">
      
          <label for="lname">Last Name</label>
          <input type="text" id="lname" name="lastname" placeholder="Your last name..">
      
          <label for="country">Country</label>
          <select id="country" name="country">
            <option value="australia">LKAMONI</option>
            <option value="canada">l3RJAT</option>
            <option value="usa">KHAROBA</option>
          </select>
      
          <label for="subject">Subject</label>
          <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>
      
          <input type="submit" value="Submit">
      
        </form>
      </div>