<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HyperGYM</title>
    <link rel="stylesheet" href="CSS.css">
</head>
<body>

    <nav>
        <div class="menu">
          <div class="logo">+
            <a href="#">HYPERGYM</a>
          </div>
          <ul>
            <li><a href="HYPERGYM.php">Home</a></li>
            <li><a href="About.php">About</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="contact.php">Contact</a></li>
        
          </ul>
        </div>
      </nav>
    
    <div class="img"></div>
    <div class="center">
      <div class="title">THE HYPER GYM</div>
      <div class="sub_title">WELCOME TO THE PERFECT PLACE </div>
      <div class="btns">
        <button onclick="window.location.href = 'About.php';">Learn More</button>
        <button onclick="window.location.href = 'register.php';">JOIN US </button>
      </div>
    </div>
  
</body>
</html>