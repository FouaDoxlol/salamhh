
<?php
  include("connect.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HyperGYM</title>
    <link rel="stylesheet" href="regi.css">
</head>
<body>

    <nav>
        <div class="menu">
            
          <div class="logo">+
            <a href="#">HYPERGYM</a>
          </div>
          <ul>
            
            <li><a href="HYPERGYM.php">Home</a></li>
            <li><a href="About.php">About</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="contact.php">Contact</a></li>
           
          </ul>
        </div>
      </nav>
    

      <!DOCTYPE html>
      
      <html lang="en" dir="ltr">
        <head>
          <meta charset="UTF-8">
        
          <link rel="stylesheet" href="style.css">
           <meta name="viewport" content="width=device-width, initial-scale=1.0">
         </head>
      <body>
        <div class="container">
          <div class="title">Registration</div>
          <div class="content">
            <form action="#">
              <div class="user-details">
                <div class="input-box">
                  <span class="details">Full Name</span>
                  <input type="text" name="full"placeholder="Enter your name" required>
                </div>
                <div class="input-box">
                  <span class="details">Username</span>
                  <input type="text" name="username" placeholder="Enter your username" required>
                </div>
                <div class="input-box">
                  <span class="details">Email</span>
                  <input type="text" name="email" placeholder="Enter your email" required>
                </div>
                <div class="input-box">
                  <span class="details">Phone Number</span>
                  <input type="number" name="phone" placeholder="Enter your number" required>
                </div>
                <div class="input-box">
                  <span class="details">Password</span>
                  <input type="password" name="pass" placeholder="Enter your password" required>
                </div>
                <div class="input-box">
                  <span class="details">Confirm Password</span>
                  <input type="password" placeholder="Confirm your password" required>
                </div>
                <div class="input-box">
                  <span class="details">Subcription mode</span>
                  <input type="text" name="sub" placeholder="Your favorite sport" required>
                </div>
                <div class="input-box">
                  <span class="details">Gender</span>
                  <input type="text" name="sexe" placeholder="Enter your gender" required>
                </div>
              </div>
              <div class="gender-details">
                <input type="radio" name="Paymment" id="dot-1">
                <input type="radio" name="Paymment" id="dot-2">
                <input type="radio" name="Paymment" id="dot-3">
                <span class="gender-title">Paymment</span>
                <div class="category">
                  <label for="dot-1">
                  <span class="dot one"></span>
                  <span class="gender">1 Month</span>
                </label>
                <label for="dot-2">
                  <span class="dot two"></span>
                  <span class="gender">3 Month</span>
                </label>
                <label for="dot-3">
                  <span class="dot three"></span>
                  <span class="gender">1 Year</span>
                  </label>
                </div>
              </div>
              <div class="button">
                <input type="submit" value="Register">
              </div>
            </form>
          </div>
        </div>
      
      </body>
      </html>
      

      
  <?php 
  

  
  function redirectHome($theMsg ,$url,$seconds=3){
  
   
       
        
      $url=$_SERVER['HTTP_REFERER'];
        $link='Previous Page';
  
  
  
   echo $theMsg;
  
   echo '<div class="alert alert-info"> You Will Be Redirected To '.$link.' After '.$seconds.' Seconds</div>';
    
   header("refresh:$seconds;url=$url");
   exit();
  
  }
  
    if($_SERVER['REQUEST_METHOD']=='POST'){
  
      
  
  
      // Get Variables From The Form
      $pass =$_POST['pass'];
      $user=$_POST['username'];
      $email=$_POST['email'];
      $name =$_POST['full'];
      $hashPass=sha1($_POST['password']);
      $sub =$_POST['sub'];
      $sexe =$_POST['sexe'];
      $paymment =$_POST['paymment'];
      $phone =$_POST['phone'];
  
  
               //Insert User Info in the db 
                      $stmt=$con->prepare("INSERT INTO 
                      users(fullname ,email, password, subcriptionMode , username , phoneNumber , sexe , paymment)
                      VALUES(:zfull , :zemail , :zpass, :zsub , :zusername , :zphone , :zsexe , :zpaymment  ");
                     
                      $stmt->execute(array(              
                      'zfull'    =>   $name,
  
                      'zemail'      =>  $email ,
  
                      'zpass'       => $hashPass  ,
  
                      'zsub '       =>   $sub  ,
  
                      'zusername'       =>   $user ,
                    
                      'zphone '       =>   $phone  ,
                    
                      'zsexe'       =>   $sexe  ,
                    
                      'zpaymment '       =>   $paymment  )); 
  
         
                      //Success message
  
                      $theMsg='<div class="alert alert-success">'.$stmt->rowCount().'Record Inserted </div>';     
  
                     redirectHome($theMsg,'back',4);
                      }
  
              
    
  
  
    
    ?>
  
  
  
</body>
</html>